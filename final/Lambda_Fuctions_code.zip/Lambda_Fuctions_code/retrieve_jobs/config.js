const config = {
    photoapp_config: "config.ini",
    photoapp_profile: "s3readwrite",
    service_port: 8080,
    page_size: 12
};

module.exports = config;
